# Write a program to implement Huffman Encoding using a greedy strategy.

import sys
import heapq
from collections import Counter
from itertools import count
from typing import Dict, Optional, Tuple
"""
prac2.py - Huffman Encoding implementation (greedy strategy)

Usage:
    - Run and enter text when prompted.
    - Or pass text as a command-line argument:
            python prac2.py "this is an example"
    - Or pass a filename with -f:
            python prac2.py -f input.txt
Outputs the codes, encoded bitstring, compression stats and decodes back to verify.
"""



class Node:
        __slots__ = ("freq", "char", "left", "right")

        def __init__(self, freq: int, char: Optional[str] = None, left: "Node" = None, right: "Node" = None):
                self.freq = freq
                self.char = char
                self.left = left
                self.right = right

        def is_leaf(self) -> bool:
                return self.char is not None


def build_huffman_tree(freqs: Counter) -> Node:
        """
        Build Huffman tree using a min-heap (greedy: always combine two smallest).
        Returns root node.
        """
        heap = []
        tie = count()  # unique sequence to avoid comparison of Node objects

        # Create leaf nodes
        for ch, fr in freqs.items():
                heapq.heappush(heap, (fr, next(tie), Node(fr, char=ch)))

        # Edge case: if only one unique character, create a dummy sibling
        if len(heap) == 1:
                fr, _, node = heapq.heappop(heap)
                dummy = Node(0, char=None)
                parent = Node(fr, left=node, right=dummy)
                return parent

        while len(heap) > 1:
                f1, _, n1 = heapq.heappop(heap)
                f2, _, n2 = heapq.heappop(heap)
                parent = Node(f1 + f2, left=n1, right=n2)
                heapq.heappush(heap, (parent.freq, next(tie), parent))

        return heapq.heappop(heap)[2]


def generate_codes(root: Node) -> Dict[str, str]:
        """
        Traverse the tree to generate binary codes for each character.
        Left edge -> '0', Right edge -> '1'.
        """
        codes: Dict[str, str] = {}

        def _walk(node: Node, prefix: str):
                if node is None:
                        return
                if node.is_leaf():
                        # If tree has only one character, give it code '0'
                        codes[node.char] = prefix or "0"
                        return
                _walk(node.left, prefix + "0")
                _walk(node.right, prefix + "1")

        _walk(root, "")
        return codes


def encode(text: str, codes: Dict[str, str]) -> str:
        return "".join(codes[ch] for ch in text)


def decode(bits: str, root: Node) -> str:
        out = []
        node = root
        for b in bits:
                node = node.left if b == "0" else node.right
                if node.is_leaf():
                        out.append(node.char)
                        node = root
        return "".join(out)


def stats(original: str, bits: str) -> Tuple[int, int, float]:
        orig_bits = len(original) * 8
        comp_bits = len(bits)
        ratio = comp_bits / orig_bits if orig_bits else 0.0
        return orig_bits, comp_bits, ratio


def read_input_from_args(argv):
        if len(argv) >= 2 and argv[1] == "-f" and len(argv) >= 3:
                fname = argv[2]
                with open(fname, "r", encoding="utf-8") as f:
                        return f.read()
        elif len(argv) >= 2:
                return " ".join(argv[1:])
        else:
                return input("Enter text to encode: ")


def main():
        text = read_input_from_args(sys.argv).rstrip("\n")
        if not text:
                print("No input provided.")
                return

        freqs = Counter(text)
        root = build_huffman_tree(freqs)
        codes = generate_codes(root)
        encoded = encode(text, codes)
        decoded = decode(encoded, root)

        print("Symbol : Frequency : Code")
        for ch, fr in sorted(freqs.items(), key=lambda x: (-x[1], x[0])):
                disp = ch if ch != "\n" else "\\n"
                print(f"'{disp}': {fr:9d} : {codes[ch]}")

        orig_bits, comp_bits, ratio = stats(text, encoded)
        print()
        print(f"Original size: {orig_bits} bits")
        print(f"Compressed size: {comp_bits} bits")
        print(f"Compression ratio: {ratio:.3f} (compressed/original)")
        print()
        print("Encoded bitstring:")
        print(encoded)
        print()
        print("Decoded equals original:", decoded == text)


if __name__ == "__main__":
        main()
