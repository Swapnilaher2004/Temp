# Write a program to solve a fractional Knapsack problem using a greedy method.

class Item:
    def __init__(self, weight, value):
        self.weight = weight
        self.value = value
        self.ratio = value / weight

def fractional_knapsack(items, capacity):
    # Sort items by value/weight ratio in descending order
    items.sort(key=lambda x: x.ratio, reverse=True)
    
    final_value = 0.0
    current_weight = 0.0
    
    # Process items
    for item in items:
        if current_weight + item.weight <= capacity:
            # Take whole item
            current_weight += item.weight
            final_value += item.value
        else:
            # Take fraction of item
            remaining = capacity - current_weight
            final_value += item.ratio * remaining
            break
            
    return final_value

def main():
    # Example usage
    weights = [10, 20, 30]
    values = [60, 100, 120]
    capacity = 80
    
    # Create items
    items = []
    for i in range(len(weights)):
        items.append(Item(weights[i], values[i]))
    
    # Calculate maximum value
    max_value = fractional_knapsack(items, capacity)
    
    print("Maximum value obtained:", max_value)

if __name__ == "__main__":
    main()