# Python program to display the Fibonacci sequence

# If n is provided, prints the first n Fibonacci numbers. Otherwise the
# program prompts the user to enter the number of terms.


import sys


def fibonacci(n: int) -> list:
    """Return a list with the first n Fibonacci numbers.

    Fib sequence used: 0, 1, 1, 2, 3, 5, ...
    """
    if n <= 0:
        return []
    seq = [0]
    if n == 1:
        return seq
    seq.append(1)
    for _ in range(2, n):
        seq.append(seq[-1] + seq[-2])
    return seq


def main() -> None:
    # Accept optional command-line argument for convenience in automated runs
    n = None
    if len(sys.argv) > 1:
        try:
            n = int(sys.argv[1])
        except ValueError:
            print(f"Invalid number: {sys.argv[1]}")
            sys.exit(1)
    else:
        try:
            n = int(input("Enter number of terms: "))
        except Exception:
            print("Invalid input")
            sys.exit(1)

    if n <= 0:
        print("Please enter a positive integer.")
        sys.exit(1)

    seq = fibonacci(n)
    print(f"Fibonacci sequence (first {n} terms):")
    print(" ".join(str(x) for x in seq))


if __name__ == "__main__":
    main()
