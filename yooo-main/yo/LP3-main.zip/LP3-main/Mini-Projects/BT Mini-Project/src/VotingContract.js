// VotingContract.js
import { ethers } from "ethers";
import contractABI from "./VotingABI.json"; // Make sure this matches your ABI filename
const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS; // Replace with actual deployed address

export const getContract = async () => {
  if (!window.ethereum) {
    alert("MetaMask not detected!");
    return null;
  }

  const provider = new ethers.BrowserProvider(
    new ethers.JsonRpcProvider(import.meta.env.VITE_RPC_URL)
  );

  const signer = await provider.getSigner(); // signer needed for sending transactions
  const contract = new ethers.Contract(contractAddress, contractABI, signer);

  return contract;
};
