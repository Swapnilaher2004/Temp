import React, { useState } from "react";
import { getContract } from "./VotingContract";

function App() {
  const [account, setAccount] = useState(null);
  const [candidates, setCandidates] = useState([]);
  const [name, setName] = useState("");

  const connectWallet = async () => {
    if (!window.ethereum) return alert("MetaMask not found!");
    const accounts = await window.ethereum.request({
      method: "eth_requestAccounts",
    });
    setAccount(accounts[0]);
  };

  const loadCandidates = async () => {
    const contract = await getContract();
    if (!contract) return;
    const names = await contract.candidates(); // Or use a loop to fetch all if needed
    setCandidates(names);
  };

  const addCandidate = async () => {
    const contract = await getContract();
    if (!contract) return;
    const tx = await contract.addCandidate(name);
    await tx.wait();
    alert(`Candidate ${name} added!`);
    setName("");
  };

  const vote = async (candidateName) => {
    const contract = await getContract();
    if (!contract) return;
    const tx = await contract.vote(candidateName);
    await tx.wait();
    alert(`You voted for ${candidateName}!`);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold mb-8">🗳️ E-Voting DApp</h1>

      {!account ? (
        <button
          onClick={connectWallet}
          className="bg-blue-500 px-6 py-3 rounded-lg hover:bg-blue-600"
        >
          Connect MetaMask
        </button>
      ) : (
        <p className="mb-4 text-green-400">Connected: {account}</p>
      )}

      <div className="flex gap-2 mb-6">
        <input
          className="text-black px-3 py-2 rounded"
          placeholder="Candidate name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button
          onClick={addCandidate}
          className="bg-green-500 px-4 py-2 rounded hover:bg-green-600"
        >
          Add
        </button>
      </div>

      <button
        onClick={loadCandidates}
        className="bg-yellow-500 px-4 py-2 rounded mb-4 hover:bg-yellow-600"
      >
        Load Candidates
      </button>

      <ul className="space-y-2">
        {candidates.map((c, i) => (
          <li
            key={i}
            className="flex justify-between bg-gray-800 px-4 py-2 rounded-lg"
          >
            <span>{c}</span>
            <button
              onClick={() => vote(c)}
              className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-600"
            >
              Vote
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
