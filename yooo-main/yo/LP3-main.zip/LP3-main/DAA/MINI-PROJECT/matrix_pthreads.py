"""
matrix_pthreads.py

A small demonstration of matrix multiplication using Python threads (per-row).
Note: This uses Python's `threading` module to illustrate the pthreads concept.
For CPU-bound work in CPython, the GIL may limit speedup; for true parallel CPU work,
use `multiprocessing` or write a C extension using pthreads.

Usage:
  python matrix_pthreads.py                # runs a 3x3 example with random values
  python matrix_pthreads.py 4 5 6         # creates A (4x5) and B (5x6) random and multiplies

"""
import threading
import random
import time
import argparse
from typing import List

Matrix = List[List[int]]


def multiply_row(A: Matrix, B: Matrix, C: Matrix, row: int) -> None:
    """Compute one row of the result matrix C = A * B."""
    cols_B = len(B[0])
    common = len(B)
    for j in range(cols_B):
        s = 0
        for k in range(common):
            s += A[row][k] * B[k][j]
        C[row][j] = s


def threaded_matmul(A: Matrix, B: Matrix) -> Matrix:
    """Multiply A (r x m) with B (m x c) using one thread per row of A.

    Returns the result matrix C (r x c).
    """
    if len(A) == 0 or len(B) == 0:
        return []
    if len(A[0]) != len(B):
        raise ValueError("A's column count must equal B's row count")

    rows_A = len(A)
    cols_B = len(B[0])
    C = [[0 for _ in range(cols_B)] for _ in range(rows_A)]

    threads = []
    for i in range(rows_A):
        t = threading.Thread(target=multiply_row, args=(A, B, C, i))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    return C


def random_matrix(rows: int, cols: int, min_val: int = 0, max_val: int = 9) -> Matrix:
    return [[random.randint(min_val, max_val) for _ in range(cols)] for _ in range(rows)]


def print_matrix(M: Matrix, name: str = "M") -> None:
    print(f"{name} ({len(M)}x{len(M[0]) if M and M[0] else 0}):")
    for row in M:
        print("\t" + " ".join(f"{v:5d}" for v in row))


def main():
    parser = argparse.ArgumentParser(description="Matrix multiplication using Python threads (per-row).")
    parser.add_argument("nrowsA", nargs="?", type=int, help="A rows (default 3)", default=3)
    parser.add_argument("ncolsA", nargs="?", type=int, help="A cols / B rows (default 3)", default=3)
    parser.add_argument("ncolsB", nargs="?", type=int, help="B cols (default 3)", default=3)
    parser.add_argument("--quiet", action="store_true", help="Don't print matrices, just time the multiplication")
    args = parser.parse_args()

    r = args.nrowsA
    m = args.ncolsA
    c = args.ncolsB

    A = random_matrix(r, m)
    B = random_matrix(m, c)

    if not args.quiet:
        print_matrix(A, "A")
        print()
        print_matrix(B, "B")
        print()

    t0 = time.perf_counter()
    C = threaded_matmul(A, B)
    t1 = time.perf_counter()

    if not args.quiet:
        print_matrix(C, "A*B")
        print()

    print(f"Computed {r}x{c} result in {t1 - t0:.6f} seconds using {r} threads (one per row)")


if __name__ == "__main__":
    main()
