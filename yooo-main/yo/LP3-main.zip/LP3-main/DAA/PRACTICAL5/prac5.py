# Design n-Queens matrix having first Queen placed. Use backtracking to place remaining Queens to generate the final n-queen’s matrix.

def print_solution(board):
    for row in board:
        print(" ".join("Q" if col else "." for col in row))
    print()

def is_safe(board, row, col, n):
    for i in range(col):
        if board[row][i]:
            return False
    for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
        if board[i][j]:
            return False
    for i, j in zip(range(row, n), range(col, -1, -1)):
        if board[i][j]:
            return False
    return True

def solve_n_queens_util(board, col, n):
    if col >= n:
        print_solution(board)
        return True
    res = False
    for i in range(n):
        if is_safe(board, i, col, n):
            board[i][col] = True
            res = solve_n_queens_util(board, col + 1, n) or res
            board[i][col] = False
    return res

def solve_n_queens(n):
    board = [[False for _ in range(n)] for _ in range(n)]
    board[0][0] = True  # Place the first queen at (0, 0)
    solve_n_queens_util(board, 1, n)

n = 4  # Change this value for different sizes of the board
solve_n_queens(n)65
